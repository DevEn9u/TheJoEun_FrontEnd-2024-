# display:block(상자)

- div, header, section, footer, ul, li, ol, dl, dt, dd, p, address, aside, nav
- 나머지 모두 block
- 가로:100%, 세로:내용만큼
- 위아래 배치
- 크기지정가능
- 마진,패딩 상하좌우 가능

# display:inline(글자)

- a, span, em, strong, label, b, i, u
- 가로,세로 크기 내용만큼
- 좌우배치되며 자간에 의해 간격이 발생
- 크기지정불가
- 마진,패딩 상하 불가

# display:inline-block

- img,input,button,select,textarea,iframe
- 기본크기
- 좌우
- 크기지정가능
- 마진,패딩 상하좌우 가능, 마진병합없음
